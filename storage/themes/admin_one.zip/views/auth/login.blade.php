@extends('layouts.empty')

@section('title')
Laraone | Login
@endsection

@section('content')
    <login v-bind="{{ json_encode($settings) }}"></login>
@endsection

@push('scripts')
    <script src="{{ mix('js/login.js', 'themes/admin_one') }}"></script>
@endpush
