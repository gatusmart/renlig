@extends('layouts.empty')

@section('title')Laraone | Activate
@endsection

@section('content')
    <activate-user :user-id="{{$userId}}" :signature-valid="{{$signatureValid}}" :forwarding-query='{!! json_encode($forwardingQuery) !!}' v-bind="{{ json_encode($settings) }}"></activate-user>
@endsection

@push('scripts')
    <script src="{{ mix('js/activate.js', 'themes/admin_one') }}{{ app()->isLocal() ? '?'.str_random(7) : null }}"></script>
@endpush
