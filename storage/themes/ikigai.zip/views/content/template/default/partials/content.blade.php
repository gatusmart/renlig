@component('content.render.rootblocks', [
    'rootBlocksIds' => $rootBlocksIds,
    'allBlocks' => $allBlocks,
])@endcomponent
