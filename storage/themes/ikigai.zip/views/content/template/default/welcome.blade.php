@extends('layouts.app')

@section('content')
    <div class="container content-wrap" style="padding-top: 30px;">
        @welcome()
        @endwelcome
    </div>
@endsection
