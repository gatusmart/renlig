{{-- @include('content/template/default/partials/content') --}}
@include('content/template/default/'.$pageType)
