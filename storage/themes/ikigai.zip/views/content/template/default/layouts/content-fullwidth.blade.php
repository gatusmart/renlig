    <div class="container content-wrap">
        <div class="content content-{{$pageType}}">
            @include('content/template/default/'.$pageType)
        </div>
    </div>