
    <div class="social-buttons">
        <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode($url) }}"
           target="_blank">
           <i class="fa fa-facebook fa-2x"></i>
        </a>
        <a href="https://twitter.com/intent/tweet?url={{ urlencode($url) }}"
           target="_blank">
            <i class="fa fa-twitter fa-2x"></i>
        </a>
        <a href="https://plus.google.com/share?url={{ urlencode($url) }}"
           target="_blank">
           <i class="fa fa-google-plus fa-2x"></i>
        </a>
    </div>
