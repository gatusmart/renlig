<footer>
    <div class="container footer-wrap">
        <div class="footer-copyright">{{ get_theme_setting('footer.general.copyright') }} {{ now()->year }}</div>
        <div class="footer-poweredby">powered by Laraone</div>
    </div>
</footer>